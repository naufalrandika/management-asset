<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Berwujud;
use App\Models\TBerwujud;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        // Menghitung total berwujud
        $totalBerwujud = Berwujud::count();

        // Menghitung total tidak berwujud
        $totalTidakBerwujud = TBerwujud::count();

        // Menghitung total keseluruhan (berwujud + tidak berwujud)
        $totalSemua = $totalBerwujud + $totalTidakBerwujud;

        $totalNilaiBerwujud = Berwujud::sum('Nilai');

        // Menghitung total nilai tidak berwujud
        $totalNilaiTidakBerwujud = TBerwujud::sum('Nilai');

        // Menghitung total nilai keseluruhan (berwujud + tidak berwujud)
        $totalNilaiSemua = $totalNilaiBerwujud + $totalNilaiTidakBerwujud;

        return view('dashboard.index', compact('totalBerwujud', 'totalTidakBerwujud', 'totalSemua', 'totalNilaiBerwujud', 'totalNilaiTidakBerwujud', 'totalNilaiSemua'));
    }
}
