<!DOCTYPE html>
<html>
<head>
    <title>Berwujud Data PDF</title>
</head>
<body>
    <h1>Berwujud Data PDF</h1>
    <table>
        <thead>
            <tr>
                <th>Kode</th>
                <th>Nama</th>
                <th>Jenis</th>
                <th>Keadaan</th>
                <th>Masa Pemakaian</th>
                <th>Tanggal Terima</th>
                <th>Nilai</th>
                <th>Status</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $item)
                <tr>
                    <td>{{ $item->kode }}</td>
                    <td>{{ $item->nama }}</td>
                    <td>{{ $item->jenis }}</td>
                    <td>{{ $item->keadaan }}</td>
                    <td>{{ $item->masa_pemakaian }}</td>
                    <td>{{ $item->tanggal_terima }}</td>
                    <td>{{ $item->Nilai }}</td>
                    <td>{{ $item->status }}</td>
                    <td>{{ $item->keterangan }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
