<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['activePage']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['activePage']); ?>
<?php foreach (array_filter((['activePage']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<aside
    class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark"
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0 d-flex text-wrap align-items-center" href=" <?php echo e(route('dashboard')); ?> ">
            <img src="https://lppm.undip.ac.id/wp-content/uploads/cropped-Ikon-Undip-192x192.png" class="navbar-brand-img h-100" alt="main_logo">
            <span class="ms-2 font-weight-bold text-white">LPPM</span>
        </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto  max-height-vh-100" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">ACCOUNT</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e($activePage == 'user-profile' ? 'active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('user-profile')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i style="font-size: 1.2rem;" class="fas fa-user-circle ps-2 pe-2 text-center"></i>
                    </div>
                    <span class="nav-link-text ms-1">User Profile</span>
                </a>
            </li>
            
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Pages</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e($activePage == 'dashboard' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('dashboard')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e($activePage == 'temperature' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('suhu')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">Temperature</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e($activePage == 'ph' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('ph')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">pH</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e($activePage == 'do' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('do')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">DO</span>
                </a>
            </li>
            
            
            
            
        </ul>
    </div>
    
</aside>
<?php /**PATH /home/u279266822/domains/penelitianlppm.online/public_html/resources/views/components/navbars/sidebar.blade.php ENDPATH**/ ?>