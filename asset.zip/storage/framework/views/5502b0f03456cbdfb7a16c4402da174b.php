<!DOCTYPE html>
<html>
<head>
    <title>Berwujud Data PDF</title>
</head>
<body>
    <h1>Berwujud Data PDF</h1>
    <table>
        <thead>
            <tr>
                <th>Kode</th>
                <th>Nama</th>
                <th>Jenis</th>
                <th>Keadaan</th>
                <th>Masa Pemakaian</th>
                <th>Tanggal Terima</th>
                <th>Nilai</th>
                <th>Status</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->kode); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->jenis); ?></td>
                    <td><?php echo e($item->keadaan); ?></td>
                    <td><?php echo e($item->masa_pemakaian); ?></td>
                    <td><?php echo e($item->tanggal_terima); ?></td>
                    <td><?php echo e($item->Nilai); ?></td>
                    <td><?php echo e($item->status); ?></td>
                    <td><?php echo e($item->keterangan); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\KKNN\management-asset\resources\views/pdf/template.blade.php ENDPATH**/ ?>